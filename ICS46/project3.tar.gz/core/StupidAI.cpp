// StupidAI.cpp
//
// ICS46 Sprign 2018 - Project 3
// Gerald Berzuela - gberzuel - 27436118
//
// Definitions for an Othello AI

#include <ics46/factory/DynamicFactory.hpp>
#include "StupidAI.hpp"
#include "OthelloGameState.hpp"
#include "OthelloCell.hpp"
#include "OthelloBoard.hpp"

ICS46_DYNAMIC_FACTORY_REGISTER(OthelloAI, gberzuel::StupidAI, "AAHHHH (Required)");

std::pair<int, int> gberzuel::StupidAI::chooseMove(const OthelloGameState& state)
{
    // Determines what color this AI is
    if(state.isBlackTurn())
        isBlack = true;
    else
        isBlack = false;
    
    // First checks if the AI can take a corner and takes it if possible
    if(checkCorners(state))
    {
        takeCorner(state);
        return thisMove;
    }
    else if(checkEdges(state))
    {
        takeEdge(state);
        return thisMove;
    }
    else
    {
        // Evaluates all the moves and gives each move an arbitrary number as a value
        // Sets the chosen x and y position for the AI in the process
        std::vector<std::pair<int, int>> validMoves = getValidMoves(state);
        evalMove(state, 4);
        
        return thisMove;
    }
}

int gberzuel::StupidAI::evalMove(const OthelloGameState& state, int depth = 4)
{
    int max, min, result;
    std::vector<std::pair<int, int>> validMoves = getValidMoves(state);
    // First check if the game is over at this state or if we have already checked four moves deep
    // if true, check the state of the board and return an arbitrary value for how good the move is
    if(depth == 0 || state.isGameOver())
    {
        return evalBoard(state);
    }
    // If it is the AI's turn
    else if((isBlack && state.isBlackTurn()) || (!isBlack && state.isWhiteTurn()))
    {
        // Create a vector of pairs that will contain the cells indices for valid moves
        // Iterates through the valid moves, creates a clone of the gamestate, makes the move,
        // checks the result of moving through that branch and sets the AI's chosen x and y
        // when the recursion comes back
        for(int i = 0; i < validMoves.size(); ++i)
        {
            std::unique_ptr<OthelloGameState> gameStateCopy = state.clone();
            gameStateCopy->makeMove(validMoves[i].first, validMoves[i].second);
            result = evalMove(*gameStateCopy, depth - 1);
            if(result >= max)
            {
                max = result;
                if(depth == 4)
                {
                    thisMove = validMoves[i];
                }
            }
        }
        return max;
    }
    // If it's not the AI's turn
    else
    {
        for(int i = 0; i < validMoves.size(); ++i)
        {
            std::unique_ptr<OthelloGameState> gameStateCopy = state.clone();
            gameStateCopy->makeMove(validMoves[i].first, validMoves[i].second);
            result = evalMove(*gameStateCopy, depth - 1);
            if(result < min)
            {
                min = result;
            }
        }
        return min;
    }
}

int gberzuel::StupidAI::evalBoard(const OthelloGameState& state)
{
    // Evaluates the value of the board based on the given term and returns an arbitrary value
    // based on the game state of whoevers turn it is
    // Return an absurdly high number if the game is over and the player has won
    if(state.isBlackTurn())
    {
        if(state.isGameOver() && (state.blackScore() > state.whiteScore()))
            return 1000;
        return blackMinusWhiteScore(state) + cornerCheck(state) + edgeCheck(state);
    }
    else
    {
        if(state.isGameOver() && (state.whiteScore() > state.blackScore()))
            return 1000;
        return whiteMinusBlackScore(state) + cornerCheck(state) + edgeCheck(state);
    }
}

int gberzuel::StupidAI::cornerCheck(const OthelloGameState& state)
{
    // Checks what tile is at each corner. Increment the result if it is in favor of the player,
    // decrement it if it's in favor of the opposing player
    const OthelloBoard& board = state.board();
    int width = state.board().width() - 1;
    int height = state.board().height() - 1;
    int result = 0;
    if(state.isBlackTurn())
    {
        if(board.cellAt(0, 0) == OthelloCell::black)
            result += 10;
        else if(board.cellAt(0, 0) == OthelloCell::white)
            result -= 10;
        if(board.cellAt(width, 0) == OthelloCell::black)
            result += 10;
        else if(board.cellAt(width, 0) == OthelloCell::white)
            result -= 10;
        if(board.cellAt(0, height) == OthelloCell::black)
            result += 10;
        else if(board.cellAt(0, height) == OthelloCell::white)
            result -= 10;
        if(board.cellAt(width, height) == OthelloCell::black)
            result += 10;
        else if(board.cellAt(width, height) == OthelloCell::white)
            result -= 10;
    }
    else
    {
        if(board.cellAt(0, 0) == OthelloCell::white)
            result += 10;
        else if(board.cellAt(0, 0) == OthelloCell::black)
            result -= 10;
        if(board.cellAt(width, 0) == OthelloCell::white)
            result += 10;
        else if(board.cellAt(width, 0) == OthelloCell::black)
            result -= 10;
        if(board.cellAt(0, height) == OthelloCell::white)
            result += 10;
        else if(board.cellAt(0, height) == OthelloCell::black)
            result -= 10;
        if(board.cellAt(width, height) == OthelloCell::white)
            result += 10;
        else if(board.cellAt(width, height) == OthelloCell::black)
            result -= 10; 
    }
    return result;
}

int gberzuel::StupidAI::edgeCheck(const OthelloGameState& state)
{
    // Checks what tile is at the each of the board (not including corners or tiles next to corners)
    // Increment the result if it is in favor of the player, decrement it is it's in favor of the 
    // opposing player
    const OthelloBoard& board = state.board();
    int width = state.board().width() - 1;
    int height = state.board().height() - 1;
    int result = 0;
    if(state.isBlackTurn())
    {
        for(int top = 2; top < width - 1; ++top)
        {
            if(board.cellAt(top, 0) == OthelloCell::black)
                result += 10;
            else if(board.cellAt(top, 0) == OthelloCell::white)
                result -= 10;
        }
        for(int bottom = 2; bottom < width - 2; ++bottom)
        {
            if(board.cellAt(bottom, height) == OthelloCell::black)
                result += 10;
            else if(board.cellAt(bottom, height) == OthelloCell::white)
                result -= 10;
        }
        for(int left = 2; left < height - 2; ++left)
        {
            if(board.cellAt(0, left) == OthelloCell::black)
                result += 10;
            else if(board.cellAt(0, left) == OthelloCell::white)
                result -= 10;
        }
        for(int right = 2; right < height - 2; ++right)
        {
            if(board.cellAt(width, right) == OthelloCell::black)
                result += 10;
            else if(board.cellAt(width, right) == OthelloCell::white)
                result -= 10;
        }
    }
    else
    {
        for(int top = 2; top < width - 1; ++top)
        {
            if(board.cellAt(top, 0) == OthelloCell::black)
                result -= 10;
            else if(board.cellAt(top, 0) == OthelloCell::white)
                result += 10;
        }
        for(int bottom = 2; bottom < width - 2; ++bottom)
        {
            if(board.cellAt(bottom, height) == OthelloCell::black)
                result -= 10;
            else if(board.cellAt(bottom, height) == OthelloCell::white)
                result += 10;
        }
        for(int left = 2; left < height - 2; ++left)
        {
            if(board.cellAt(0, left) == OthelloCell::black)
                result -= 10;
            else if(board.cellAt(0, left) == OthelloCell::white)
                result += 10;
        }
        for(int right = 2; right < height - 2; ++right)
        {
            if(board.cellAt(width, right) == OthelloCell::black)
                result -= 10;
            else if(board.cellAt(width, right) == OthelloCell::white)
                result += 10;
        }
    }
    return result;
}

bool gberzuel::StupidAI::checkCorners(const OthelloGameState& state)
{
    // Returns true if any of the corners are available to be taken by the current player of the gamestate
    int width = state.board().width() - 1;
    int height = state.board().height() - 1;
    return (state.isValidMove(0,0) || state.isValidMove(width, 0) || 
                state.isValidMove(0, height) || state.isValidMove(width, height));
}

void gberzuel::StupidAI::takeCorner(const OthelloGameState& state)
{
    // Finds the corner the player can take and sets that as thisMove
    int width = state.board().width() - 1;
    int height = state.board().height() - 1;
    if(state.isValidMove(0, 0))
    {
        thisMove = std::make_pair(0, 0);
    }
    if(state.isValidMove(width, 0))
    {
        thisMove = std::make_pair(width, 0);
    }
    if(state.isValidMove(0, height))
    {
        thisMove = std::make_pair(0, height);
    }
    if(state.isValidMove(width, height))
    {
        thisMove = std::make_pair(width, height);
    }
}

bool gberzuel::StupidAI::checkEdges(const OthelloGameState& state)
{
    // Returns true if any of the edges not next to a corner are availabe to be taken by the current player
    int width = state.board().width() - 1;
    int height = state.board().height() - 1;
    for(int top = 2; top < width - 1; ++top)
    {
        if(state.isValidMove(top, 0))
            return true;
    }
    for(int bottom = 2; bottom < width - 2; ++bottom)
    {
        if(state.isValidMove(bottom, height))
            return true;
    }
    for(int left = 2; left < height - 2; ++left)
    {
        if(state.isValidMove(0, left))
            return true;
    }
    for(int right = 2; right < height - 2; ++right)
    {
        if(state.isValidMove(width, right))
            return true;
    }
    return false;
}

int gberzuel::StupidAI::takeEdge(const OthelloGameState& state)
{
    // finds the edge the player can take and sets that as thisMove
    int width = state.board().width() - 1;
    int height = state.board().height() - 1;
    for(int top = 2; top < width - 1; ++top)
    {
        if(state.isValidMove(top, 0))
        {
            thisMove = std::make_pair(top, 0);
            return 0;
        }
    }
    for(int bottom = 2; bottom < width - 2; ++bottom)
    {
        if(state.isValidMove(bottom, height))
        {
            thisMove = std::make_pair(bottom, height);
            return 0;
        }
    }
    for(int left = 2; left < height - 2; ++left)
    {
        if(state.isValidMove(0, left))
        {
            thisMove = std::make_pair(0, left);
            return 0;
        }
    }
    for(int right = 2; right < height - 2; ++right)
    {
        if(state.isValidMove(width, right))
        {
            thisMove = std::make_pair(width, right);
            return 0;
        }
    }
    return 0;
}

int gberzuel::StupidAI::blackMinusWhiteScore(const OthelloGameState& state)
{
    return state.blackScore() - state.whiteScore();
}

int gberzuel::StupidAI::whiteMinusBlackScore(const OthelloGameState& state)
{
    return state.whiteScore() - state.blackScore();
}

std::vector<std::pair<int, int>> gberzuel::StupidAI::getValidMoves(const OthelloGameState& state)
{
    std::vector<std::pair<int, int>> result;
    for(int x = 0; x < state.board().width(); ++x)
    {
        for(int y = 0; y < state.board().height(); ++y)
        {
            if(state.isValidMove(x, y))
                result.push_back(std::make_pair(x, y));
        }
    }
    return result;
}
