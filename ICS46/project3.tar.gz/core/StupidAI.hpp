// StupidAI.hpp
//
// ICS46 Spring 2018 - Project 3
// Gerald Berzuela - gberzuel - 27436118
//
// Declarations for an Othello playing AI

#ifndef STUPIDAI_HPP
#define STUPIDAI_HPP


#include "OthelloAI.hpp"
#include "OthelloGameState.hpp"

namespace gberzuel
{
    class StupidAI : public OthelloAI
    {
    public:
        virtual std::pair<int, int> chooseMove(const OthelloGameState& state);
    private:
        bool isBlack;
        std::pair<int, int> thisMove;
        int evalMove(const OthelloGameState& state, int depth);
        int evalBoard(const OthelloGameState& state);
        int cornerCheck(const OthelloGameState& state);
        int edgeCheck(const OthelloGameState& state);
        bool checkCorners(const OthelloGameState& state);
        void takeCorner(const OthelloGameState& state);
        bool checkEdges(const OthelloGameState& state);
        int takeEdge(const OthelloGameState& state);
        int blackMinusWhiteScore(const OthelloGameState& state);
        int whiteMinusBlackScore(const OthelloGameState& state);
        std::vector<std::pair<int, int>> getValidMoves(const OthelloGameState& state);
    };
}


#endif // STUPIDAI_HPP
