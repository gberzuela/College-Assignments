// String.cpp
//
// ICS 46 Spring 2018
// Project #0: Getting to Know the ICS 46 VM
//
// Implement all of your String member functions in this file.
//
// Note that the entire standard library -- both the C Standard
// Library and the C++ Standard Library -- is off-limits for this
// task, as the goal is to exercise your low-level implementation
// skills (pointers, memory management, and so on).

#include "String.hpp"
#include "OutOfBoundsException.hpp"

// Public member functions:
// Default constructor creates an empty string
String :: String()
    : buf(new char[1])
{
    buf[0] = '\0';
}

// Explicit constructor that takes in a char* and sets it to buf
// Uses strlen() to find the len of the char* to allocate exact amount
// of memory
String :: String(const char* chars)
    : buf(new char[strlen(chars) + 1])
{
    strcpy(buf, chars);
}

// Copy constructor that copies s.buf to this buf
String :: String(const String& s)
    : buf(new char[s.length() + 1])
{
    strcpy(buf, s.buf);
}

// Destructor simply deletes the character array, buf
String :: ~String() noexcept
{
    delete[] buf;
}

// Assignment operator deletes this buf and allocates memory 
// according to the length of s and copies the contents of s.buf
// to this buf
String& String :: operator=(const String& s)
{
    delete[] buf;
    buf = new char[s.length() + 1];
    
    strcpy(buf, s.buf);
    
    return *this;
}

// Creates a temporary variable of size length() + s.length() + 1
// First copies buf to temp, deletes buf, concatenates s.buf to temp
// dynamically allocate buf with the size of temp and finally copies
// temp into buf
void String :: append(const String& s)
{
    char* temp = new char[this->length() + s.length() + 1];
    strcpy(temp, buf);
    delete[] buf;

    strcat(temp, s.buf);
    buf = new char[strlen(temp) + 1];
    strcpy(buf, temp);
    delete[] temp;
}

// char at(): basically the indexing operator but throws an
// OutOfBoundsException if the index is out of range
char String :: at(unsigned int index) const
{
    if(index >= this->length())
        throw(OutOfBoundsException{});
    else
        return buf[index];
}

// char& at(): indexing operator but returns a reference to the char
// for possible modification and throws an OutOfBoundsException
// if index is out of range
char& String :: at(unsigned int index)
{
    if(index >= this->length())
        throw(OutOfBoundsException{});
    else
        return buf[index];
}

// void clear(): deletes this buf and sets it to be an empty string
void String :: clear()
{
    delete[] buf;
    buf = new char[1];
    buf[0] = '\0';
}

// int compareTo(): compares contents of this string to the contents of another 
// string, returning zero if they're exactly equal, a positive value if this
// string is greater, and a negative value if this string is lesser
int String :: compareTo(const String& s) const noexcept
{
    for(int i = 0; buf[i] != '\0'; ++i)
    {
        if((buf[i] != s.buf[i]) || buf[i] == '\0' || s.buf[i] == '\0')
            return buf[i] - s.buf[i];
    }
    return 0;
}

// String concatenate(): creates a new String object with buf and s.buf
// appended to one another
String String :: concatenate(const String& s) const
{
    char temp[length() + s.length()];
    strcpy(temp, buf);
    strcat(temp, s.buf);
    String result(temp);
    return result; 
}

// bool contains(): checks to see if a substring is within buf
bool String :: contains(const String& substring) const noexcept
{
    return find(substring) == -1 ? false : true;
}

// bool equals(): checks to see if buf and s are equal by checking the 
// length of each and calling compareTo()
bool String :: equals(const String& s) const noexcept
{
    return length() == s.length() && compareTo(s) == 0;
}

// int find(): returns the index where a given substring is found
// returns -1 otherwise
int String :: find(const String& substring) const noexcept
{
    if(this->isEmpty())
        return 0;

    for(int i = 0; (i + substring.length()) < this->length(); i++)
    {   
        String temp = this->substring(i, i + substring.length());
        if(temp.equals(substring))
            return i;
    }
    return -1;
}

// bool isEmpty(): checks to see if the string is empty by checking the length
bool String :: isEmpty() const noexcept
{
    return strlen(buf) == 0;
}

// int length(): member function explicit to this class to get the length of buf
// by calling a private member function, strlen()
unsigned int String :: length() const noexcept
{
    return strlen(buf);
}

// String substring(): returns a substring of buf from startIndex to (endIndex - 1)
// If any index is out of range, throws OutOfBoundsException
// If startIndex > endIndex, return an empty string
String String :: substring(unsigned int startIndex, unsigned int endIndex) const
{
    if(endIndex > this->length())
        throw(OutOfBoundsException{});
    else if(startIndex > endIndex)
    {  
        String emptyResult;
        return emptyResult;
    }
    else
    {
        char temp[endIndex - startIndex];

        int i = 0; // To iterate through temps indexes
        for(int j = startIndex; j < endIndex; j++)
            temp[i++] = buf[j];
        temp[i] = '\0';

        String result(temp);
        
        return result;
    }
}

// toChars(): if buf is a nullptr (length == 0) return "" otherwise return buf 
const char* String :: toChars() const noexcept
{
    return (buf == nullptr) ? "" : buf;
}

// Private member functions:
// strlen(): used to get the length of a char* argument
int String :: strlen(const char* s)
{
    int len = 0;

    for(int i = 0; s[i] != '\0'; i++)
        len++;

    return len;
}

// strcpy(): used to copy or overwrite a string from a source to a destination
char* String :: strcpy(char* dest, const char* src)
{
    int i;
    for(i = 0; src[i] != '\0'; ++i)
        dest[i] = src[i];
    dest[i] = '\0';

    return dest;
}

// strcat(): calls strcpy with the length and contents of the destination to add source
char* String :: strcat(char* dest, const char* src)
{
    strcpy(dest + strlen(dest), src);
    return dest;
}
