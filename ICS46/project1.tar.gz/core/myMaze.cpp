#include <ics46/factory/DynamicFactory.hpp>
#include "Maze.hpp"
#include "myMaze.hpp"
#include <random>

ICS46_DYNAMIC_FACTORY_REGISTER(MazeGenerator, myMaze, "myMaze (Required)");

myMaze::myMaze()
{
}

void myMaze::generateMaze( Maze& maze )
{  
    // Add all walls to begin with
    maze.addAllWalls();

    // Create a vector of vectors of bool to determine if that cell has been visited
    for ( int i = 0; i < maze.getHeight(); i++ )
    {
        std::vector<bool> rows;
        for ( int j = 0; j < maze.getWidth(); j++ )
        {
            rows.push_back(false);
        }
        cells.push_back(rows);
    }
    
    createPath( 0, 0, maze );
}

void myMaze::createPath( int x, int y, Maze& maze )
{
    // Pseudorandom Generator
    std::random_device device;
    std::default_random_engine engine( device () );

    while(true)
    {
        cells[y][x] = true;
        
        // Creates a vector of all possible directions we can go from a cell
        std::vector<Direction> options = checkOptions( x, y, maze );
        std::uniform_int_distribution<int> distribution( 0, options.size() - 1 );
        int randInt = distribution( engine );
    
        // First checks if all cells have been visited
        if( allVisited( maze ) || options.size() == 0 )
            return;
        // Generators a random index to determine what direction to go
        if( options[randInt] == Direction::up )
        {
            maze.removeWall( x, y, Direction::up );
            createPath( x, y - 1, maze );
        }
        if( options[randInt] == Direction::down )
        {
            maze.removeWall( x, y, Direction::down );
            createPath( x, y + 1, maze );
        }
        if( options[randInt] == Direction::left )
        {
            maze.removeWall( x, y, Direction::left );
            createPath( x - 1, y, maze );
        }
        if( options[randInt] == Direction::right )
        {
            maze.removeWall( x, y, Direction::right );
            createPath( x + 1, y, maze );
        }
    }
} 

bool myMaze::allVisited( Maze& maze )
{
    // Iterates through a vector of vector of bool to check if all the cells have been visited
    for ( int i = 0; i < maze.getHeight(); i++ )
    {
        for ( int j = 0; j < maze.getWidth(); j++ )
        {
            if ( cells[i][j] == false )
            {
                return false;
            }
        }
    }
    return true;
}

std::vector<Direction> myMaze::checkOptions( int x, int y, Maze& maze )
{
    // Creates a vector of avaiable directions at a given positoin
    std::vector<Direction> options;
    if( 0 <= (y - 1) && !cells[y - 1][x] && maze.wallExists( x, y, Direction::up ) )
        options.push_back( Direction::up );
    if( (y + 1) < maze.getHeight() && !cells[y + 1][x] && maze.wallExists( x, y, Direction::down ) )
        options.push_back( Direction::down );
    if( 0 <= (x - 1) && !cells[y][x - 1] && maze.wallExists( x, y, Direction::left ) )
        options.push_back( Direction::left );
    if( (x + 1) < maze.getWidth() && !cells[y][x + 1] && maze.wallExists( x, y, Direction::right ) )
        options.push_back( Direction:: right );

    return options;
}
