#ifndef MYSOLVER_HPP
#define MYSOLVER_HPP

#include "Maze.hpp"
#include "MazeSolver.hpp"
#include "Direction.hpp"

class mySolver : public MazeSolver
{
public:
    mySolver();
    virtual ~mySolver() = default;
    virtual void solveMaze( const Maze& maze, MazeSolution& mazeSolution );
private:
    virtual void makeMove( std::vector< std::vector<bool> >& cells, const Maze& maze, MazeSolution& mazeSolution );
    virtual std::vector< std::vector<bool> > initCellsVector( const Maze& maze );
    virtual bool isSurrounded( int x, int y, const Maze& maze );
    virtual bool checkBackUpCases( std::pair<int, int> pos, std::vector< std::vector<bool> > cells, const Maze& maze, MazeSolution& mazeSolution );
};

#endif // MYSOLVER_HPP
