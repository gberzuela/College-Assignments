#ifndef MYMAZE_HPP
#define MYMAZE_HPP

#include "MazeGenerator.hpp"
#include "Direction.hpp"

class myMaze : public MazeGenerator
{
public:
    myMaze();
    virtual void generateMaze( Maze& maze );
    virtual ~myMaze() = default;
private:
    std::vector< std::vector<bool> > cells;
    virtual void createPath( int x, int y, Maze& maze );
    virtual bool allVisited( Maze& maze );
    virtual std::vector<Direction> checkOptions( int x, int y, Maze& maze );
};

#endif // MYMAZE_HPP
