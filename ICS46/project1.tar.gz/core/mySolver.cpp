#include <ics46/factory/DynamicFactory.hpp>
#include "mySolver.hpp"
#include "MazeSolution.hpp"
ICS46_DYNAMIC_FACTORY_REGISTER(MazeSolver, mySolver, "AAA (Required)");

mySolver::mySolver()
{
}

void mySolver::solveMaze( const Maze& maze, MazeSolution& mazeSolution )
{
    // Creates a vector of vector of bool to help determine if a cell has been visited
    std::vector< std::vector<bool> > cells = initCellsVector( maze );

    // Algorithm to find solution
    makeMove( cells, maze, mazeSolution );
}

void mySolver::makeMove( std::vector< std::vector<bool> >& cells, const Maze& maze, MazeSolution& mazeSolution )
{
    // First checks if the solution is complete
    if( mazeSolution.isComplete() )
    {
        return;
    }
    else
    {
        // For convenience, use these x and y values to pass
        int x = mazeSolution.getCurrentCell().first;
        int y = mazeSolution.getCurrentCell().second;

        // Change this cell to be visited
        cells[x][y] = true;

        // First checks possible scenarios to back up
        if( checkBackUpCases( mazeSolution.getCurrentCell(), cells, maze, mazeSolution ) )
        {
            mazeSolution.backUp();
            makeMove( cells, maze, mazeSolution );
            return;
        }
        // Checks indexing boundaries, if the cell has been not visited, and if a wall is not there
        // make a move in that direction and call makeMove again
        if( (x + 1) < maze.getWidth() && !cells[x + 1][y] && !maze.wallExists( x, y, Direction::right ) )
        {
            mazeSolution.extend( Direction::right );
            makeMove( cells, maze, mazeSolution );
            return;
        }
        if( (y + 1) < maze.getHeight() && !cells[x][y + 1] && !maze.wallExists( x, y, Direction::down ) )
        { 
            mazeSolution.extend( Direction::down );
            makeMove( cells, maze, mazeSolution );
            return;
        }
        if( 0 <= (x - 1) && !cells[x - 1][y] && !maze.wallExists( x, y, Direction::left ) )
        {
            mazeSolution.extend( Direction::left );
            makeMove( cells, maze, mazeSolution );
            return;
        }
        if( 0<= (y - 1) && !cells[x][y - 1] && !maze.wallExists( x, y, Direction::up ) )
        {
            mazeSolution.extend( Direction::up );
            makeMove( cells, maze, mazeSolution );
            return;
        }
    }
}

std::vector< std::vector<bool> > mySolver::initCellsVector( const Maze& maze )
{
    // Define/declare a vector of vector of bool objects to determine if a cell has been visited
    std::vector< std::vector<bool> > cells;
    for( int i = 0; i < maze.getWidth(); ++i )
    {
        std::vector<bool> columns;
        for( int j = 0; j < maze.getHeight(); ++j )
        {
            columns.push_back( false );
        }
        cells.push_back( columns );
    }

    return cells;
}

bool mySolver::isSurrounded( int x, int y, const Maze& maze )
{
    // Checks all possible scenarios in which the path would be surrounded
    if( maze.wallExists( x, y, Direction::up ) && maze.wallExists( x, y, Direction::left ) && maze.wallExists( x, y, Direction::right ) )
        return true;
    if( maze.wallExists( x, y, Direction::up ) && maze.wallExists( x, y, Direction::left ) && maze.wallExists( x, y, Direction::down ) )
        return true;
    if( maze.wallExists( x, y, Direction::up ) && maze.wallExists( x, y, Direction::right ) && maze.wallExists( x, y, Direction::down ) )
        return true;
    if( maze.wallExists( x, y, Direction::right ) && maze.wallExists( x, y, Direction::down ) && maze.wallExists( x, y, Direction::left ) )
        return true;

    return false;
}

bool mySolver::checkBackUpCases( std::pair<int, int> pos, std::vector< std::vector<bool> > cells, const Maze& maze, MazeSolution& mazeSolution )
{
    int x = pos.first;
    int y = pos.second;
    // Checks if the cell is surrounded and isn't the starting cell in case the starting cell only has one way to go
    if( isSurrounded(x, y, maze) && pos != mazeSolution.getStartingCell() )
        return true;
    // Find tunnels we've been through
    if( 0 <= (y - 1) && (y + 1) < maze.getHeight() && cells[x][y - 1] && cells[x][y + 1] && maze.wallExists( x, y, Direction::left ) && maze.wallExists( x, y, Direction::right ) )
        return true;
    if( 0 <= (x - 1) && (x + 1) < maze.getWidth() && cells[x - 1][y] && cells[x + 1][y] && maze.wallExists( x, y, Direction::up ) && maze.wallExists( x, y, Direction::down ) )
        return true;
    // Finds corners we've been through
    if( 0 <= (x- 1) && (y + 1) < maze.getHeight() && cells[x - 1][y] && cells[x][y + 1] && maze.wallExists( x, y, Direction::right ) && maze.wallExists( x, y, Direction::up ) )
        return true;
    if( 0 <= (x- 1) && 0 <= (y - 1) && cells[x - 1][y] && cells[x][y - 1] && maze.wallExists( x, y, Direction::right ) && maze.wallExists( x, y, Direction::down ) ) 
        return true;
    if( (x + 1) < maze.getWidth() && (y + 1) < maze.getHeight() && cells[x + 1][y] && cells[x][y + 1] && maze.wallExists( x, y, Direction::left ) && maze.wallExists( x, y, Direction::up ) )
        return true;
    if( (x + 1) < maze.getWidth() && 0 <= (y - 1) && cells[x + 1][y] && cells[x][y - 1] && maze.wallExists( x, y, Direction::left ) && maze.wallExists( x, y, Direction::down ) )
        return true;
    // Finds T intersections
    if( 0 <= (x - 1) && (x + 1) < maze.getWidth() && (y + 1) < maze.getHeight() && maze.wallExists( x, y, Direction::up ) && cells[x - 1][y] && cells[x + 1][y] && cells[x][y + 1] )
        return true;
    if( 0 <= (x - 1) && (x + 1) < maze.getWidth() && 0<= (y - 1) && maze.wallExists( x, y, Direction::down ) && cells[x - 1][y] && cells[x + 1][y] && cells[x][y - 1] )
        return true;
    if( 0 <= (x - 1) && 0 <= (y - 1) && (y + 1) < maze.getHeight() && maze.wallExists( x, y, Direction::right ) && cells[x - 1][y] && cells[x][y - 1] && cells[x][y + 1] )
        return true;
    if( (x + 1) < maze.getWidth() && 0 <= (y - 1) && (y + 1) < maze.getHeight() && maze.wallExists( x, y, Direction::left ) && cells[x + 1][y] && cells[x][y - 1] && cells[x][y + 1] )
        return true;
    return false;
}
