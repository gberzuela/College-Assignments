// main.cpp
//
// ICS 46 Spring 2018
// Project #2: Time Waits for No One
//
// This is the entry point for your simulation application.
//
// All of the code that makes up your simulation -- which is everything
// except for your DoublyLinkedList and Queue implementations -- should
// be in the "app" directory, though, naturally, it shouldn't all be in
// this file.  A design that keeps separate things separate is always
// part of the requirements.
#include <iostream>
#include "Queue.hpp"
#include <vector>
#include <math.h>

int getSimLength()
{
    int length;
    while (!(std::cin >> length) || length == 0)
    {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "Invalid input for SIMULATION LENGTH. Try again: " << std::endl;
    }
    return length;
}

int getRegisters()
{
    int registers;
    while(!(std::cin >> registers) || registers == 0)
    {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "Invalid input for NUMBER OF REGISTERS. Try again: " << std::endl;
    }
    return registers;
}


int getLineLength()
{
    int line;
    while (!(std::cin >> line) || line == 0)
    {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "Invalid input for LINE LENGTH. Try again: " << std::endl;
    }
    return line;
}


char getLineType()
{
    char type;
    while (true)
    {
        std::cin >> type;
        if (isalpha(type))
        {
            if (type == 'S' || type == 'M')
                return type;
            else
            {
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                std::cout << "Invalid input for LINE TYPE. Enter S or M: " << std::endl;
            }
        }
        else
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input for LINE TYPE. Enter S or M: " << std::endl;
        }
    }
}


std::vector< std::pair<int, int> > registerInfo(int regNum)
{
    std::vector< std::pair<int, int> > regInfo;
    for (int i = 0; i < regNum; ++i)
    {
        int time;
        std::cin >> time;
        regInfo.push_back(std::pair<int, bool> (time, 0));
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    return regInfo;
}


std::vector< Queue<std::pair<int, int>> > fillQueues(int regNum)
{
    std::vector< Queue<std::pair<int, int>> > queues;
    for (int i = 0; i < regNum; ++i)
    {
        Queue<std::pair<int, int>> q;
        queues.push_back(q);
    }
    return queues;
}


std::vector< std::pair<int, int> > getSimInputs()
{  
    std::vector< std::pair<int, int> > result;
    while((std::cin >> std::ws).peek() != std::char_traits<char>::to_int_type('E'))
    {
        int customers, arrivalTime;
        std::cin >> customers;
        std::cin >> arrivalTime;
        result.push_back(std::pair<int, int> (arrivalTime, customers));
    }
    return result;
}


bool linesFull(std::vector< Queue<std::pair<int, int>> > queues, int len)
{
    for(int i = 0; i < queues.size(); ++i)
    {
        if(queues[i].size() < len)
            return false;
    }
    return true;
}


int findShortestLine(std::vector< Queue<std::pair<int, int>> > queues, int len)
{
    int index = 0;
    int shortest = queues[index].size();
    for(int i = 1; i < queues.size(); ++i)
    {
        if (queues[i].size() < shortest)
        {
            index = i;
            shortest = queues[i].size();
        }
    }
    return index;
}


float getAvgWaitTime(std::vector<int> waitTime)
{
    float result = 0.0;
    for(int i = 0; i < waitTime.size(); ++i)
    {
        result += waitTime[i];
    }
    return result/waitTime.size();
}


int getLeftInLine(std::vector< Queue<std::pair<int, int>> > queues)
{
    int result = 0;
    for(int i = 0; i < queues.size(); ++i)
    {
        result += queues[i].size();
    }
    return result;
}


int getLeftInReg(std::vector< std::pair<int, int> > reg)
{
    int result = 0;
    for(int i = 0; i < reg.size(); ++i)
    {
        if (reg[i].second != 0)
            result++;
    }
    return result;
}


void moveLine(std::vector< std::pair<int, int> >& reg, std::vector< Queue<std::pair<int, int>> >& queues, int currentTime, int& exitedLine, int& exitedRegister, std::vector<int>& waitTime)
{
    for(int i = 0; i < queues.size(); ++i)
    {
        if (!queues[i].isEmpty() && reg[i].second == 0)
        {
            std::cout << currentTime << " exited line " << i + 1 << " length " << queues[i].size() - 1<< " wait time " << currentTime - queues[i].front().second << std::endl;
            std::cout << currentTime << " entered register " << i + 1 << std::endl;
            // Add the current time to the time it will take this register to process a
            // transaction to reprsent the time this person will leave
            reg[i].second = currentTime + reg[i].first;
            exitedLine++;
            waitTime.push_back(currentTime - queues[i].front().second);
            queues[i].dequeue();
        }
        else if (!queues[i].isEmpty() && reg[i].second == currentTime)
        {
            std::cout << currentTime << " exited register " << i + 1 << std::endl;
            std::cout << currentTime << " exited line " << i + 1 << " length " << queues[i].size() - 1 << " wait time " << currentTime - queues[i].front().second << std::endl;
            std::cout << currentTime << " entered register " << i + 1 << std::endl;
            reg[i].second = currentTime + reg[i].first;
            exitedRegister++;
            exitedLine++;
            waitTime.push_back(currentTime - queues[i].front().second);
            queues[i].dequeue();
        }
    }
}


void printStats(int enteredLine, int exitedLine, int exitedReg, float avgWaitTime, int leftInLine, int leftInReg, int lost)
{
    std::cout << "STATS" << std::endl;
    std::cout << "Entered Line" << '\t' << ": " << enteredLine << std::endl;
    std::cout << "Exited Line" << "\t\t" << ": " << exitedLine << std::endl;
    std::cout << "Exited Register" << '\t' << ": " << exitedReg << std::endl;
    std::cout << "Avg Wait Time" << '\t' << ": " << floorf(avgWaitTime*100)/100 << std::endl;
    std::cout << "Left In Line" << '\t' << ": " << leftInLine << std::endl;
    std::cout << "Left in Register: " << leftInReg << std::endl;
    std::cout << "Lost" << "\t\t\t" << ": " << lost << std::endl;
}


void runSimulation(int time, int len, std::vector< std::pair<int, int> >& reg, 
                        std::vector< Queue<std::pair<int, int>> >& queues, std::vector< std::pair<int, int> > inputs)
{
    // Variables to keep track of for stats
    int enteredLine = 0;
    int exitedLine = 0;
    int exitedRegister = 0;
    std::vector<int> waitTime;
    int lost = 0;
    int currentTime = 0;

    std::cout << "LOG" << std::endl;
    std::cout << currentTime << " start" << std::endl;

    while (currentTime < time)
    {
        int arrivalTime = 0;
        int customers = 0;

        // Checks if customers arrive
        for(int i = 0; i < inputs.size(); ++i)
        {
            if (inputs[i].first == currentTime)
            {
                arrivalTime = inputs[i].first;
                customers = inputs[i].second;
            }
        }

        while (!linesFull(queues, len) && customers > 0)
        {
            // Find the shortest line then add the customers to that line, incrementing enteredLine for stats
            int shortest = findShortestLine(queues, len);

            if (queues[shortest].size() == 0 && reg[shortest].second == 0)
            {
                queues[shortest].enqueue(std::pair<int, int>(arrivalTime + reg[shortest].first, arrivalTime));
                std::cout << arrivalTime << " entered line " << shortest + 1 << " length " << queues[shortest].size() << std::endl;
                enteredLine++;
                customers--;
            }
            else if (queues[shortest].size() == 0 && reg[shortest].second != 0)
            {
                queues[shortest].enqueue(std::pair<int, int>((arrivalTime + (reg[shortest].first)), arrivalTime));
                std::cout << arrivalTime << " entered line " << shortest + 1 << " length " << queues[shortest].size() << std::endl;
                enteredLine++;
                customers--;
            }
            else
            {
                queues[shortest].enqueue(std::pair<int, int>((arrivalTime + (reg[shortest].first * queues[shortest].size())), arrivalTime));
                std::cout << arrivalTime << " entered line " << shortest + 1 << " length " << queues[shortest].size() << std::endl;
                enteredLine++;
                customers--;
            }
        }
        
        moveLine(reg, queues, currentTime, exitedLine, exitedRegister, waitTime);

        // Mark the rest as lost
        while(customers > 0)
        {
            lost++;
            customers--;
            std::cout << currentTime << " lost" << std::endl;
        }
        currentTime++;
    }
    
    float avgWaitTime = getAvgWaitTime(waitTime);
    int leftInLine = getLeftInLine(queues);
    int leftInReg = getLeftInReg(reg);
    
    std::cout << time << " end" << '\n' << std::endl;
    printStats(enteredLine, exitedLine, exitedRegister, avgWaitTime, leftInLine, leftInReg, lost);
}

/*
void runSimulation(int time, int len, std::vector< std::pair<int, int> > reg, Queue< std::pair<int, int> > queues, std:: vector< std::pair<int, int> > inputs)
{   
    // Variables to keep of for stats
    int enteredLine = 0;
    int exitedLine = 0;
    int exitedRegister = 0;
    std::vector<int> waitTime;
    int lost = 0;
    int currentTime = 0;

    std::cout << "LOG" << std::endl;
    std::cout << currentTime << " start" << std::endl; 

    while (currentTime < time)
    {
        int arrivalTime = 0;
        int customers = 0;

        for(int i = 0; i < inputs.size(); ++i)
        {
            if(inputs[i].first == currentTime)
            {
                arrivalTime == inputs[i].first;
                customers == inputs[i].second;
            }
        }

        // Populate the list
        while (!queues.isEmpty() && customers > 0)
        {
            int nextReg = findNextReg(reg);
            queues.enqueue(std::pair<int, int>(
        }
    }
    return;
}*/


int main()
{
    // Simulator length, number of registers, max length of a line, and type of line inputs
    int simLength = 60 * getSimLength();
    int regNum = getRegisters();
    int lineLength = getLineLength();
    char lineType = getLineType();

    // Create a vector of a pair<int, int> to keep track of register information
    // First int will determine how long it will take to process each customer
    // Second int will determine when the customer should leave.
    std::vector< std::pair<int, int> > registers = registerInfo(regNum);
    
    // Creates a vector of a pair<int, int> to store the remaining inputs
    std::vector< std::pair<int, int> > inputs = getSimInputs();

    // If the type of line is 'M,' create a vector of Queue<int> to represent the line for 
    // each register and use ints to represent the people in each line
    // If the type of the line is 'S,' create a single Queue<int> to represent the line
    // every customer will wait in and use ints to represent the people
    // There are two different runSimulation algorithms for the given data structure for the lines
    if (lineType == 'M')
    {
        // Create a Queue of pair<int, int> to represent each person
        // First int will determine the estimated time they should wait until
        // Second int will store when they arrived
        std::vector< Queue<std::pair<int, int>> > queues = fillQueues(regNum);
        runSimulation(simLength, lineLength, registers, queues, inputs);
    }
    else if (lineType == 'S')
    {
        std::cout << "I could not finish in time." << std::endl;
     //   Queue< std::pair<int, int> > queues;
     //   runSimulation(simLength, lineLength, registers, queues, inputs);
    }

    return 0;
}

