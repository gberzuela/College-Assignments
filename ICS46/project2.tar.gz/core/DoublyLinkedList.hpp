// DoublyLinkedList.hpp
//
// ICS 46 Spring 2018
// Project #2: Time Waits for No One
//
// DoublyLinkedList<ValueType> is a class template that implements a
// doubly-linked list with head and tail pointers, including two kinds
// of iterators: One of them allows viewing and modifying the list's
// contents, while the other allows only viewing them.
//
// Your goal is to implement the entire public interface *exactly* as
// specified below.  Do not modify the signatures of any of the public
// member functions (including the public member functions of the various
// iterator classes) in any way.  We will be running extensive unit
// tests against your implementation, which will not compile unless
// things remain completely unchanged.  As we did in Project #0, we've
// provided you a basic set of unit tests that briefly demonstrate how
// each of the member functions is required to behave; you'll find
// those in the "gtest" directory.
//
// All of the public member functions listed with "noexcept" in their
// signature must be implemented in a way that they never throw exceptions.
// All of the others are expected to make the "strong" exception guarantee,
// which means two things: (1) no memory has leaked, and (2) the contents
// of the list/iterator will not have visibly changed in the event that
// an exception has been thrown.
//
// The entire C++ Standard Library is off-limits in your implementation
// of this class.  DO NOT submit a version of this file (or any file
// that it includes) that includes any C++ Standard Library headers.
// (This includes things like adding a print() member function that
// requires <iostream>.)
//
// As is good custom in class templates, keep the interface separate
// from the implementation.  This means the bodies of member functions
// should not be written in the class declaration, but should appear
// below it.  I've placed "dummy" implementations of every public
// member function, though, of course, most of them don't do the
// right thing; but they will save you some typing and demonstrate
// the structure of what you should be writing.

#ifndef DOUBLYLINKEDLIST_HPP
#define DOUBLYLINKEDLIST_HPP

#include "EmptyException.hpp"
#include "IteratorException.hpp"



template <typename ValueType>
class DoublyLinkedList
{
    // The forward declarations of these classes allows us to establish
    // that they exist, but delay displaying all of the details until
    // later in the file.
    //
    // (This is generally a good style, with the most important details
    // appearing earlier in the class declaration.  That's the same
    // reason why we're implementing the bodies of the member functions
    // outside of the class declaration.)
public:
    class Iterator;
    class ConstIterator;

private:
    struct Node;


public:
    // Initializes this list to be empty.
    DoublyLinkedList() noexcept;

    // Initializes this list as a copy of an existing one.
    DoublyLinkedList(const DoublyLinkedList& list);

    // Initializes this list from an expiring one.
    DoublyLinkedList(DoublyLinkedList&& list) noexcept;


    // Destroys the contents of this list.
    virtual ~DoublyLinkedList() noexcept;


    // Replaces the contents of this list with a copy of the contents
    // of an existing one.
    DoublyLinkedList& operator=(const DoublyLinkedList& list);

    // Replaces the contents of this list with the contents of an
    // expiring one.
    DoublyLinkedList& operator=(DoublyLinkedList&& list) noexcept;


    // addToStart() adds a value to the start of the list, meaning that
    // it will now be the first value, with all subsequent elements still
    // being in the list (after the new value) in the same order.
    void addToStart(const ValueType& value);

    // addToEnd() adds a value to the end of the list, meaning that
    // it will now be the last value, with all subsequent elements still
    // being in the list (before the new value) in the same order.
    void addToEnd(const ValueType& value);


    // removeFromStart() removes a value from the start of the list, meaning
    // that the list will now contain all of the values *in the same order*
    // that it did before, *except* that the first one will be gone.
    // In the event that the list is empty, an EmptyException will be thrown.
    void removeFromStart();

    // removeFromEnd() removes a value from the end of the list, meaning
    // that the list will now contain all of the values *in the same order*
    // that it did before, *except* that the last one will be gone.
    // In the event that the list is empty, an EmptyException will be thrown.
    void removeFromEnd();


    // first() returns the value at the start of the list.  In the event that
    // the list is empty, an EmptyException will be thrown.  There are two
    // variants of this member function: one for a const DoublyLinkedList and
    // another for a non-const one.
    const ValueType& first() const;
    ValueType& first();


    // last() returns the value at the end of the list.  In the event that
    // the list is empty, an EmptyException will be thrown.  There are two
    // variants of this member function: one for a const DoublyLinkedList and
    // another for a non-const one.
    const ValueType& last() const;
    ValueType& last();


    // isEmpty() returns true if the list has no values in it, false
    // otherwise.
    bool isEmpty() const noexcept;


    // size() returns the number of values in the list.
    unsigned int size() const noexcept;



    // There are two kinds of iterators supported: Iterators and
    // ConstIterators.  They have similar characteristics; they both
    // allow you to see what values are in the list and move back and
    // forth between them.  The difference is that ConstIterators allow
    // you to see the elements but not modify them, while Iterators also
    // support modification of the list (both by modifying the elements
    // directly, and also by inserting or removing values at arbitrary
    // locations).
    //
    // At any given time, an iterator refers to a value in the list.
    // There are also two additional places it can refer: "past start"
    // and "past end", which are the positions directly before the
    // first value and directly after the last one, respectively.
    // Except with respect to those boundaries, they can be moved
    // both forward and backward.
    //
    // Note, too, that the reason we have a ConstIterator class instead
    // of just saying "const Iterator" is because a "const Iterator"
    // is something different: It's an Iterator object that you can't
    // modify (i.e., you can't move it around).  What a ConstIterator
    // holds constant isn't the iterator; it's the list that's protected
    // by it.


    // iterator() creates a new Iterator over this list.  It will
    // initially be referring to the first value in the list, unless the
    // list is empty, in which case it will be considered both "past start"
    // and "past end".
    Iterator iterator();


    // constIterator() creates a new ConstIterator over this list.  It will
    // initially be referring to the first value in the list, unless the
    // list is empty, in which case it will be considered both "past start"
    // and "past end".
    ConstIterator constIterator() const;


public:
    // The IteratorBase class is the base class for our two kinds of
    // iterators.  Because there are so many similarities between them,
    // we write those similarities in a base class, then inherit from
    // that base class to specify only the differences.
    class IteratorBase
    {
    public:
        // Initializes a newly-constructed IteratorBase to operate on
        // the given list.  It will initially be referring to the first
        // value in the list, unless the list is empty, in which case
        // it will be considered to be both "past start" and "past end".
        IteratorBase(const DoublyLinkedList& list) noexcept;


        // moveToNext() moves this iterator forward to the next value in
        // the list.  If the iterator is refrering to the last value, it
        // moves to the "past end" position.  If it is already at the
        // "past end" position, an IteratorException will be thrown.
        void moveToNext();


        // moveToPrevious() moves this iterator backward to the previous
        // value in the list.  If the iterator is refrering to the first
        // value, it moves to the "past start" position.  If it is already
        // at the "past start" position, an IteratorException will be thrown.
        void moveToPrevious();


        // isPastStart() returns true if this iterator is in the "past
        // start" position, false otherwise.
        bool isPastStart() const noexcept;


        // isPastEnd() returns true if this iterator is in the "past end"
        // position, false otherwise.
        bool isPastEnd() const noexcept;
    
    protected:
        // You'll want protected member variables and member functions,
        // which will be accessible to the derived classes.
        
        // Keep track of where the iterator is
        Node* current;

        // Used to determine when the iterator is in a past start/end position
        bool pastStart;
        bool pastEnd;
    };


    class ConstIterator : public IteratorBase
    {
    public:
        // Initializes a newly-constructed ConstIterator to operate on
        // the given list.  It will initially be referring to the first
        // value in the list, unless the list is empty, in which case
        // it will be considered to be both "past start" and "past end".
        ConstIterator(const DoublyLinkedList& list) noexcept;


        // value() returns the value that the iterator is currently
        // referring to.  If the iterator is in the "past start" or
        // "past end" positions, an IteratorException will be thrown.
        const ValueType& value() const;
    };


    class Iterator : public IteratorBase
    {
    public:
        // Initializes a newly-constructed Iterator to operate on the
        // given list.  It will initially be referring to the first
        // value in the list, unless the list is empty, in which case
        // it will be considered to be both "past start" and "past end".
        Iterator(DoublyLinkedList& list) noexcept;


        // value() returns the value that the iterator is currently
        // referring to.  If the iterator is in the "past start" or
        // "past end" positions, an IteratorException will be thrown.
        ValueType& value() const;


        // insertBefore() inserts a new value into the list before
        // the one to which the iterator currently refers.  If the
        // iterator is in the "past start" position, an IteratorException
        // is thrown.
        void insertBefore(const ValueType& value);


        // insertAfter() inserts a new value into the list after
        // the one to which the iterator currently refers.  If the
        // iterator is in the "past end" position, an IteratorException
        // is thrown.
        void insertAfter(const ValueType& value);


        // remove() removes the value to which this iterator refers,
        // moving the iterator to refer to either the value after it
        // (if moveToNextAfterward is true) or before it (if
        // moveToNextAfterward is false).  If the iterator is in the
        // "past start" or "past end" position, an IteratorException
        // is thrown.
        void remove(bool moveToNextAfterward = true);
    };


private:
    // A structure that contains the vital parts of a Node in a
    // doubly-linked list, the value and two pointers: one pointing
    // to the previous node (or nullptr if there isn't one) and
    // one pointing to the next node (or nullptr if there isn't
    // one).
    struct Node
    {
        ValueType value;
        Node* prev;
        Node* next;
        
        // Copy constructor for nodes and copy member function to help
        Node(ValueType newValue, Node* newPrev, Node* newNext);
        static Node* copy(Node* n);

        // Used to find tail during construction
        static Node* findTail(Node* n);

        // Called to delete any DoublyLinkedList
        static void deleteList(Node* n);
    };


    // You can feel free to add private member variables and member
    // functions here; there's a pretty good chance you'll need some.
    Node* head;
    Node* tail;
};


//    Node member functions definitions    //
// Node explicit constructor
template <typename ValueType>
DoublyLinkedList<ValueType>::Node::Node(ValueType newValue, Node* newPrev, Node* newNext)
    : value(newValue), prev(newPrev), next(newNext)
{
}

// Used in DLL's copy constructor to recursively create a new Node, who's previous value
// will be the current node and the next value being the current node's next value
template <typename ValueType>
typename DoublyLinkedList<ValueType>::Node* DoublyLinkedList<ValueType>::Node::copy(Node* n)
{
    return n == nullptr ? nullptr : new Node(n->value, n->prev, copy(n->next));
}

// Used in DLL's copy constructor to find the tail of the node using a for loop
template <typename ValueType>
typename DoublyLinkedList<ValueType>::Node* DoublyLinkedList<ValueType>::Node::findTail(Node* n)
{
    Node* temp;
    for(temp = n; temp != nullptr; temp = temp->next)
    {
        if (temp->next == nullptr)
            return temp;
    }
    return temp;
}

// Used to make the destructor more convenient, recursively calls next and deletes the nodes
template <typename ValueType>
void DoublyLinkedList<ValueType>::Node::deleteList(Node* n)
{
    if (n != nullptr)
    {
        deleteList(n->next);
        delete n;
    }
}


//    Public member functions for DoublyLinkedList   //
template <typename ValueType>
DoublyLinkedList<ValueType>::DoublyLinkedList() noexcept
    : head(nullptr), tail(nullptr)
{
}


template <typename ValueType>
DoublyLinkedList<ValueType>::DoublyLinkedList(const DoublyLinkedList& list)
    : head(DoublyLinkedList<ValueType>::Node::copy(list.head)), 
        tail(DoublyLinkedList<ValueType>::Node::findTail(list.head))
{
}


template <typename ValueType>
DoublyLinkedList<ValueType>::DoublyLinkedList(DoublyLinkedList&& list) noexcept
    : head(nullptr), tail(nullptr)
{
    head = list.head;
    tail = list.tail;

    list.head = nullptr;
    list.tail = nullptr;
}


template <typename ValueType>
DoublyLinkedList<ValueType>::~DoublyLinkedList() noexcept
{
    DoublyLinkedList<ValueType>::Node::deleteList(head);
}


template <typename ValueType>
DoublyLinkedList<ValueType>& DoublyLinkedList<ValueType>::operator=(const DoublyLinkedList& list)
{
    DoublyLinkedList<ValueType>::Node::deleteList(head);

    head = DoublyLinkedList<ValueType>::Node::copy(list.head);
    tail = list.tail;
    
    return *this;
}


template <typename ValueType>
DoublyLinkedList<ValueType>& DoublyLinkedList<ValueType>::operator=(DoublyLinkedList&& list) noexcept
{
    // Set temp variables to be copies of the arguments head and tail
    Node* tempHead = list.head;
    Node* tempTail = list.tail;
    
    list.head = head;
    list.tail = tail;
    
    head = tempHead;
    tail = tempTail;
    
    return *this;
}


template <typename ValueType>
void DoublyLinkedList<ValueType>::addToStart(const ValueType& value)
{
    if (isEmpty())
    {
        tail = new Node(value, nullptr, nullptr);
        head = tail;
    }
    else //if (head != nullptr)
    {
        head->prev = new Node(value, nullptr, nullptr);
        head->prev->next = head;
        head = head->prev;
    }
}


template <typename ValueType>
void DoublyLinkedList<ValueType>::addToEnd(const ValueType& value)
{
    if (isEmpty())
    {
        tail = new Node(value, nullptr, nullptr);
        head = tail;
    }
    else //if (tail != nullptr)
    {
        tail->next = new Node(value, nullptr, nullptr);
        tail->next->prev = tail;
        tail = tail->next;
    }
}


template <typename ValueType>
void DoublyLinkedList<ValueType>::removeFromStart()
{
    if (isEmpty())
        throw EmptyException();
    else if (head == tail)
    {
        delete head;

        head = nullptr;
        tail = nullptr;
    }
    else
    {
        Node* temp = head->next;
        delete head;
        head = temp;
        head->prev = nullptr;
    }
}


template <typename ValueType>
void DoublyLinkedList<ValueType>::removeFromEnd()
{
    // First checks if the DLL is empty and throws an EmptyException
    // Then checks if head and tail are pointing to the same thing
    //  
    if (this->isEmpty())
        throw EmptyException();
    else if (tail == head)
    {
        delete tail;

        head = nullptr;
        tail = nullptr;
    }
    else
    {
        Node* temp = tail->prev;
        delete tail;
        tail = temp;
        tail->next = nullptr;
    }
}


template <typename ValueType>
const ValueType& DoublyLinkedList<ValueType>::first() const
{
    // Checks if the DLL is empty and throws an EmptyException if true
    // Returns the head's value otherwise
    if (isEmpty())
        throw EmptyException();
    return head->value;
}


template <typename ValueType>
ValueType& DoublyLinkedList<ValueType>::first()
{
    // Checks if the DLL is empty and throws an EmptyException if true
    // Returns the hea'ds value otherwise
    if (isEmpty())
        throw EmptyException();
    return head->value;
}


template <typename ValueType>
const ValueType& DoublyLinkedList<ValueType>::last() const
{
    // Checks if the DLL is empty and throws an EmptyException if true
    // Returns the tail's value otherwise
    if (isEmpty())
        throw EmptyException();
    return tail->value;
}


template <typename ValueType>
ValueType& DoublyLinkedList<ValueType>::last()
{
    // Checks if the DLL is empty and throws an EmptyException if true
    // Returns the tails value otherwise
    if (isEmpty())
        throw EmptyException();
    return tail->value;
}


template <typename ValueType>
unsigned int DoublyLinkedList<ValueType>::size() const noexcept
{
    int size = 0;
    if (head == nullptr)
        return size;

    for(Node* temp = head; temp != nullptr; temp = temp->next)
    {
        size++;
    }
    return size;
}


template <typename ValueType>
bool DoublyLinkedList<ValueType>::isEmpty() const noexcept
{
    return (head == nullptr && tail == nullptr);
}


template <typename ValueType>
typename DoublyLinkedList<ValueType>::Iterator DoublyLinkedList<ValueType>::iterator()
{
    return Iterator{*this};
}


template <typename ValueType>
typename DoublyLinkedList<ValueType>::ConstIterator DoublyLinkedList<ValueType>::constIterator() const
{
    return ConstIterator{*this};
}

//    IteratorBase (base class)   //
template <typename ValueType>
DoublyLinkedList<ValueType>::IteratorBase::IteratorBase(const DoublyLinkedList& list) noexcept
    : current(list.head)
{
    // Ternary statment; "If list is empty, this variable is true, false otherwise
    pastStart = list.isEmpty() ? true : false;
    pastEnd = list.isEmpty() ? true : false;
}


template <typename ValueType>
void DoublyLinkedList<ValueType>::IteratorBase::moveToNext()
{
    // Checks if the current node is "past end" and throws an IteratorException if true
    // If the next object is a nullptr, simply change pastEnd to be true
    // Otherwise, set pastEnd to be false and the current node to be the next node
    if (pastEnd)
        throw IteratorException();
    else if (current->next == nullptr)
        pastEnd = true;
    else
    {
        pastEnd = false;
        current = current->next;
    }
}


template <typename ValueType>
void DoublyLinkedList<ValueType>::IteratorBase::moveToPrevious()
{
    // Checks if the current node is "past start" and throws an IteratorException if true
    // If the previous object is a nullptr, simply change pastStart to be true
    // Otherwise, set pastStart to be false and the current node to be the next node
    if (pastStart)
        throw IteratorException();
    else if (current->prev == nullptr)
        pastStart = true;
    else
    {
        pastStart = false;
        current = current->prev;
    }
}


template <typename ValueType>
bool DoublyLinkedList<ValueType>::IteratorBase::isPastStart() const noexcept
{
    return pastStart;
}


template <typename ValueType>
bool DoublyLinkedList<ValueType>::IteratorBase::isPastEnd() const noexcept
{
    return pastEnd;
}

//    ConstIterator (derived class)   //
template <typename ValueType>
DoublyLinkedList<ValueType>::ConstIterator::ConstIterator(const DoublyLinkedList& list) noexcept
    : IteratorBase{list}
{
}


template <typename ValueType>
const ValueType& DoublyLinkedList<ValueType>::ConstIterator::value() const
{
    // Checks if the current node is either "past start" or "past end" and throws
    //  and IteratorException if true
    // Otherwisse, just return the current node's value
    if (this->pastStart || this->pastEnd)
        throw IteratorException();
    return this->current->value;
}

//    Iterator (derived class)   //
template <typename ValueType>
DoublyLinkedList<ValueType>::Iterator::Iterator(DoublyLinkedList& list) noexcept
    : IteratorBase{list}
{
}


template <typename ValueType>
ValueType& DoublyLinkedList<ValueType>::Iterator::value() const
{
    // Checks if the current node is either "past start" or "past end" and throws
    //  an IteratorException if true
    // Otherwise, just return the current node's value
    if(this->pastStart || this->pastEnd)
        throw IteratorException();
    return this->current->value;
}


template <typename ValueType>
void DoublyLinkedList<ValueType>::Iterator::insertBefore(const ValueType& value)
{
    // First checks if the iterator is in a past start position and throws
    // an IteratorException if it is
    if (this->pastStart)
    {
        throw IteratorException();
    }
    // Otherwise, set a new Node, newNode, to have the value of the passed argument
    // the previous value to be the previous node of the current node, and the next
    // value to be the current node
    // Fixes the surrounding nodes; the current node's previous value to be the 
    // new Node and the previous node's next value to be the new Node
    else if (this->current->prev == nullptr)
    {
        Node* newNode = new Node(value, nullptr, this->current);
        this->current->prev = newNode;
    }
    else
    {
        Node* newNode = new Node(value, this->current->prev, this->current);
        this->current->prev->next = newNode;
        this->current->prev = newNode;
    }
}


template <typename ValueType>
void DoublyLinkedList<ValueType>::Iterator::insertAfter(const ValueType& value)
{
    // First checks if the iterator is in a past end position and throws
    // an IteratorException if it is
    if (this->pastEnd)
    {
        throw IteratorException();
    }
    // Otherwise, set a new Node, newNode to have the value of the passed argument
    // the previous value to be the current iterator, and the next value to be
    // the next object from the current node
    // Fixes the surrounding nodes; the next node's previous object to be the new Node
    // and the current node's next object to be the new Node
    else if (this->current->next == nullptr)
    {
        Node* newNode = new Node(value, this->current, nullptr);
        this->current->next = newNode;
    }
    else
    {
        Node* newNode = new Node(value, this->current, this->current->next);
        this->current->next->prev = newNode;
        this->current->next = newNode;
    }
}


template <typename ValueType>
void DoublyLinkedList<ValueType>::Iterator::remove(bool moveToNextAfterward)
{
    // First checks if the iterator is already in a past start/end position and throws
    // an IteratorException if it is
    if (this->pastStart || this->pastEnd)
        throw IteratorException();
    // Remove then move forward
    else if (moveToNextAfterward)
    {
        if (this->current->next == nullptr)
        {
            // One object in DLL
            if (this->current->prev == nullptr)
            {
                delete this->current;
                this->pastStart = true;
                this->pastEnd = true;
            }
            // Current is tail
            else
            {
                this->current = this->current->prev;
                delete this->current->next;
                this->current->next = nullptr;
            }
        }
        else
        {
            // Current is head
            if (this->current->prev == nullptr)
            {
                this->current = this->current->next;
                delete this->current->prev;
                this->current->prev = nullptr;
            }
            // Current in in middle
            else
            {
                Node* temp = new Node(this->current->value, this->current->prev, this->current->next);
                this->current->prev->next = this->current->next;
                this->current = this->current->next;
                delete this->current->prev;
                this->current->prev = temp->prev;
                delete temp;
            }
        }
    }
    // Remove then move backward
    else if (!moveToNextAfterward)
    {
        if (this->current->prev == nullptr)
        {
            // One object in DLL
            if (this->current->next == nullptr)
            {
                delete this->current;
                this->pastStart = true;
                this->pastStart = true;
            }
            // Current is head
            else
            {
                this->current = this->current->next;
                delete this->current->next;
                this->current->next = nullptr;
            }
        }
        else
        {
            // Current is tail
            if (this->current->next == nullptr)
            {
                this->current = this->current->prev;
                delete this->current->next;
                this->current->next = nullptr;
            }
            // Current in middle of DLL
            else
            {
                Node* temp = new Node(this->current->value, this->current->prev, this->current->next);
                this->current->next->prev = this->current->prev;
                this->current = this->current->prev;
                delete this->current->next;
                this->current->next = temp->next;
                delete temp;
            }
        }
    }
}



#endif

